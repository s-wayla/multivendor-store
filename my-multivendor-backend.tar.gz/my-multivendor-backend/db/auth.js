// db/auth.js - دوال المصادقة وإدارة المستخدمين
// يحتوي على: insertUser, getAllUsers, updateUser, deleteUser,
// getUserById, updateUserRole, getUserByEmail

const { pool } = require('./connection');
const bcrypt = require('bcryptjs');

// --- دوال المستخدمين ---
async function insertUser(name, email, password, role = 'customer') {
  let client;
  try {
    client = await pool.connect();
    const hashedPassword = await bcrypt.hash(password, 10);
    const res = await client.query(
      `INSERT INTO users (name, email, password, role)
       VALUES ($1, $2, $3, $4)
       RETURNING id, name, email, role, created_at, updated_at;`,
      [name, email, hashedPassword, role]
    );
    return res.rows[0];
  } catch (err) {
    console.error('Error inserting user:', err.stack);
    throw err;
  } finally {
    if (client) client.release();
  }
}

async function getAllUsers() {
  let client;
  try {
    client = await pool.connect();
    const res = await client.query(
      'SELECT id, name, email, role, status, is_deleted, suspended_at, deleted_at, created_at, updated_at FROM users;'
    );
    return res.rows;
  } catch (err) {
    console.error('Error fetching users:', err.stack);
    throw err;
  } finally {
    if (client) client.release();
  }
}

async function updateUser(id, newName, newEmail, newPassword) {
  let client;
  try {
    client = await pool.connect();
    let hashedPassword = newPassword;
    if (newPassword) {
      hashedPassword = await bcrypt.hash(newPassword, 10);
    }
    const res = await client.query(
      `UPDATE users
         SET name = COALESCE($1, name),
             email = COALESCE($2, email),
             password = COALESCE($3, password),
             updated_at = CURRENT_TIMESTAMP
       WHERE id = $4
       RETURNING id, name, email, role, created_at, updated_at;`,
      [newName, newEmail, hashedPassword, id]
    );
    return res.rows[0];
  } catch (err) {
    console.error('Error updating user:', err.stack);
    throw err;
  } finally {
    if (client) client.release();
  }
}

/**
 * تحاول قراءة archive_retention_days من جدول settings (ثم site_settings لو غير موجود)
 * تعيد fallback إذا لم يوجد العمود/الجدول.
 */
async function resolveRetentionDays(client, fallback = 90) {
  // حاول من جدول settings
  try {
    const r1 = await client.query(
      `SELECT archive_retention_days AS days
         FROM settings
        ORDER BY id ASC
        LIMIT 1`
    );
    if (r1.rows.length && Number.isInteger(r1.rows[0].days)) {
      return r1.rows[0].days;
    }
  } catch (_) {
    // تجاهل الخطأ
  }

  // حاول من جدول site_settings (لو موجود لديك)
  try {
    const r2 = await client.query(
      `SELECT archive_retention_days AS days
         FROM site_settings
        ORDER BY id ASC
        LIMIT 1`
    );
    if (r2.rows.length && Number.isInteger(r2.rows[0].days)) {
      return r2.rows[0].days;
    }
  } catch (_) {
    // تجاهل الخطأ
  }

  return fallback;
}

/** مساعد: إرجاع أعمدة الجدول بالترتيب */
async function getTableColumns(client, tableName) {
  const { rows } = await client.query(
    `SELECT column_name
       FROM information_schema.columns
      WHERE table_schema = 'public' AND table_name = $1
      ORDER BY ordinal_position`,
    [tableName]
  );
  return rows.map(r => r.column_name);
}

/**
 * حذف (فعليًا: أرشفة + تعليم كـ deleted)
 * - ينسخ المستخدم إلى users_archive مع retention_until
 * - ينسخ منتجاته إلى products_archive ويعطّل الأصلية (is_active = false)
 * - لا يحذف صف users لتفادي مشاكل FK
 */
async function deleteUser(id, { reason = 'account_closure', retentionDays } = {}) {
  let client;
  try {
    client = await pool.connect();
    await client.query('BEGIN');

    // 1) تأكد المستخدم موجود
    const u = await client.query('SELECT * FROM users WHERE id = $1', [id]);
    if (u.rows.length === 0) {
      await client.query('ROLLBACK');
      return null;
    }

    // 2) احسب retention_until (من الإعدادات إن لم تُمرَّر)
    const daysToKeep = Number.isInteger(retentionDays)
      ? retentionDays
      : await resolveRetentionDays(client, 90);

    const r = await client.query(
      `SELECT (NOW() + ($1 || ' days')::interval) AS until`,
      [daysToKeep]
    );
    const retentionUntil = r.rows[0].until;

    // --- تحصين: تأكيد أعمدة الأرشيف موجودة ---
    await client.query(`
      ALTER TABLE users_archive
        ADD COLUMN IF NOT EXISTS archived_at TIMESTAMPTZ,
        ADD COLUMN IF NOT EXISTS archive_reason TEXT,
        ADD COLUMN IF NOT EXISTS retention_until TIMESTAMPTZ,
        ADD COLUMN IF NOT EXISTS last_contact_at TIMESTAMPTZ
    `);
    await client.query(`
      ALTER TABLE products_archive
        ADD COLUMN IF NOT EXISTS archived_at TIMESTAMPTZ,
        ADD COLUMN IF NOT EXISTS archive_reason TEXT,
        ADD COLUMN IF NOT EXISTS retention_until TIMESTAMPTZ
    `);

    // 3) أرشفة المستخدم بأعمدة محددة صراحةً + ON CONFLICT UPDATE
    const userCols = await getTableColumns(client, 'users');               // أعمدة users بالترتيب
    const userColsList = userCols.map(c => `"${c}"`).join(', ');
    const userColsSelect = userCols.map(c => `u."${c}"`).join(', ');
    await client.query(
      `
      INSERT INTO users_archive (${userColsList}, "archived_at", "archive_reason", "retention_until", "last_contact_at")
      SELECT ${userColsSelect}, NOW(), $2, $3, NULL
        FROM users u
       WHERE u.id = $1
      ON CONFLICT ("id") DO UPDATE
        SET "archived_at" = EXCLUDED."archived_at",
            "archive_reason" = EXCLUDED."archive_reason",
            "retention_until" = EXCLUDED."retention_until"
      `,
      [id, reason, retentionUntil]
    );

    // 4) أرشفة المنتجات + تعطيل ظهورها في الأصل (أعمدة محددة صراحةً) + ON CONFLICT UPDATE
    const prodCols = await getTableColumns(client, 'products');
    const prodColsList = prodCols.map(c => `"${c}"`).join(', ');
    const prodColsSelect = prodCols.map(c => `p."${c}"`).join(', ');
    await client.query(
      `
      INSERT INTO products_archive (${prodColsList}, "archived_at", "archive_reason", "retention_until")
      SELECT ${prodColsSelect}, NOW(), $2, $3
        FROM products p
       WHERE p.vendor_id = $1
      ON CONFLICT ("id") DO UPDATE
        SET "archived_at" = EXCLUDED."archived_at",
            "archive_reason" = EXCLUDED."archive_reason",
            "retention_until" = EXCLUDED."retention_until"
      `,
      [id, reason, retentionUntil]
    );

    await client.query(
      `UPDATE products
          SET is_active = FALSE
        WHERE vendor_id = $1`,
      [id]
    );

    // 5) وسم المستخدم كـ deleted (بدون حذف الصف)
    const res = await client.query(
      `UPDATE users
          SET status = 'deleted',
              is_deleted = TRUE,
              deleted_at = NOW(),
              updated_at = NOW()
        WHERE id = $1
        RETURNING id, name`,
      [id]
    );

    await client.query('COMMIT');
    return res.rows[0];
  } catch (err) {
    if (client) await client.query('ROLLBACK');
    console.error('Error deleting user (archiving):', err.stack);
    throw err;
  } finally {
    if (client) client.release();
  }
}

/**
 * تعليق حساب + إخفاء المنتجات
 */
async function suspendUser(id, reason = 'policy_violation') {
  const res = await pool.query(
    `UPDATE users
        SET status = 'suspended',
            suspension_reason = $2,
            suspended_at = NOW(),
            updated_at = NOW()
      WHERE id = $1
        AND status = 'active'
      RETURNING id, name, status, suspended_at`,
    [id, reason]
  );
  // إخفاء المنتجات أثناء التعليق
  await pool.query(
    `UPDATE products
        SET is_active = FALSE
      WHERE vendor_id = $1`,
    [id]
  );
  return res.rows[0] || null;
}

/**
 * استرجاع حساب + إظهار المنتجات
 */
async function restoreUser(id) {
  const res = await pool.query(
    `UPDATE users
        SET status = 'active',
            suspension_reason = NULL,
            suspended_at = NULL,
            updated_at = NOW()
      WHERE id = $1
      RETURNING id, name, status`,
    [id]
  );
  // إعادة تفعيل المنتجات
  await pool.query(
    `UPDATE products
        SET is_active = TRUE
      WHERE vendor_id = $1`,
    [id]
  );
  return res.rows[0] || null;
}

/**
 * تنظيف الأرشيف: يحذف منتهيي الاحتفاظ الذين لم يتواصلوا بعد الأرشفة
 */
async function sweepArchive() {
  let client;
  try {
    client = await pool.connect();
    await client.query('BEGIN');

    // احذف منتجات منتهية الاحتفاظ
    await client.query(
      `DELETE FROM products_archive
        WHERE retention_until <= NOW()`
    );

    // احذف مستخدمين منتهيي الاحتفاظ ولم يحدث تواصل بعد الأرشفة
    await client.query(
      `DELETE FROM users_archive ua
        WHERE ua.retention_until <= NOW()
          AND COALESCE(ua.last_contact_at, ua.archived_at) <= ua.archived_at`
    );

    await client.query('COMMIT');
    return { ok: true };
  } catch (e) {
    if (client) await client.query('ROLLBACK');
    throw e;
  } finally {
    if (client) client.release();
  }
}

async function getUserById(userId) {
  let client;
  try {
    client = await pool.connect();
    const res = await client.query(
      `SELECT id, name, email, role, created_at, updated_at
         FROM users
        WHERE id = $1;`,
      [userId]
    );
    return res.rows[0];
  } catch (err) {
    console.error('Error getting user by ID:', err.stack);
    throw err;
  } finally {
    if (client) client.release();
  }
}

async function updateUserRole(userId, newRole) {
  let client;
  try {
    client = await pool.connect();
    const res = await client.query(
      `UPDATE users
          SET role = $1,
              updated_at = CURRENT_TIMESTAMP
        WHERE id = $2
        RETURNING id, name, email, role, updated_at;`,
      [newRole, userId]
    );
    return res.rows[0];
  } catch (err) {
    console.error('Error updating user role:', err.stack);
    throw err;
  } finally {
    if (client) client.release();
  }
}

async function getUserByEmail(email) {
  let client;
  try {
    client = await pool.connect();
    const res = await client.query(
      `SELECT id, name, email, password, role
         FROM users
        WHERE email = $1;`,
      [email]
    );
    return res.rows[0];
  } catch (err) {
    console.error('Error getting user by email:', err.stack);
    throw err;
  } finally {
    if (client) client.release();
  }
}

module.exports = {
  insertUser,
  getAllUsers,
  updateUser,
  deleteUser,       // أرشفة + تعليم كمحذوف
  suspendUser,
  sweepArchive,
  restoreUser,
  getUserById,
  updateUserRole,
  getUserByEmail,
};
