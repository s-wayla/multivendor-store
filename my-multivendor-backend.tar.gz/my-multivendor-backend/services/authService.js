// services/authService.js
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const SALT_ROUNDS = 10;
const JWT_EXPIRES_IN = '7d';

function normalizeEmail(email) {
  return (email || '').trim().toLowerCase();
}

async function hashPassword(plain) {
  return bcrypt.hash(plain, SALT_ROUNDS);
}

async function comparePassword(plain, hash) {
  return bcrypt.compare(plain, hash);
}

function signJWT(payload) {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error('JWT_SECRET is not set');
  return jwt.sign(payload, secret, { expiresIn: JWT_EXPIRES_IN });
}

module.exports = { normalizeEmail, hashPassword, comparePassword, signJWT };
